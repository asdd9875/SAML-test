import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth-service.component';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  isLoggedIn = false;
  nickname: string;
  constructor(private _authService: AuthService) {
    this._authService.loginChanged.subscribe(loggedIn => {
      this.isLoggedIn = loggedIn;
      if(loggedIn){
        this._authService.getUserName().then( nickname =>{
          this.nickname = nickname;
        });
        ;
      }
    })
  }

  ngOnInit() {
    this._authService.isLoggedIn().then(loggedIn => {
      this.isLoggedIn = loggedIn;
    })
  }

  login() {
    this._authService.login();
  }

  logout() {
    this._authService.logout();
  }
  

}
