import { Component, OnInit } from '@angular/core';
import { PubliceventsWebApiService } from 'src/app/services/WebApi/publicevents.WebApi.service';
import { HomeEvent } from 'src/model/homeevent';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public publicEvents: HomeEvent[];
  public loading: boolean =  false;
  constructor(
    private publicevent: PubliceventsWebApiService
  ) { }

  ngOnInit() {
    this.publicevent.getPublicEvents().toPromise()
    .then(events =>{ 
      this.publicEvents = events;
      this.loading = true;
      console.log(events);
    });
  }

}
