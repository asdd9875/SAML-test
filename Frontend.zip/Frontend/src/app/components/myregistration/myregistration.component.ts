import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myregistration',
  templateUrl: './myregistration.component.html',
  styleUrls: ['./myregistration.component.css']
})
export class MyregistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
