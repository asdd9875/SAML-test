import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-session-track',
  templateUrl: './session-track.component.html',
  styleUrls: ['./session-track.component.css']
})
export class SessionTrackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
