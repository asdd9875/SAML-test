import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/app/app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { EventComponent } from './components/event/event.component';
import { MyregistrationComponent } from './components/myregistration/myregistration.component';
import { SessionComponent } from './components/event/session/session.component';
import { SessionTrackComponent } from './components/event/session-track/session-track.component';
import { SpeakerComponent } from './components/event/speaker/speaker.component';
import { InformationComponent } from './components/event/information/information.component';
import { CoreModule } from './services/core.module';
import { SigninRedirectCallbackComponent } from './components/app/signin-redirect-callback.component';
import { SignoutRedirectCallbackComponent } from './components/app/signout-redirect-callback.component';
import { PubliceventsWebApiService } from './services/WebApi/publicevents.WebApi.service';

@NgModule({
  bootstrap: [AppComponent],
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    SigninRedirectCallbackComponent,
    SignoutRedirectCallbackComponent,
    FooterComponent,
    EventComponent,
    MyregistrationComponent,
    SessionComponent,
    SessionTrackComponent,
    SpeakerComponent,
    InformationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CoreModule,
    AppRoutingModule
  ],
  providers: [
    PubliceventsWebApiService
  ],
})
export class AppModule { }
