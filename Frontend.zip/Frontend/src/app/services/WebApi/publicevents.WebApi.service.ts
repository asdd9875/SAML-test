import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HomeEvent} from 'src/model/homeevent';
import { Observable, from } from 'rxjs';
import { AuthService } from '../auth-service.component';
import { Constants } from 'src/app/constants';
@Injectable()
export class PubliceventsWebApiService {
  constructor(private httpClient: HttpClient,
    private _authService: AuthService) { }
  public getPublicEvents(): Observable<HomeEvent[]> {
   // return this.httpClient.get<HomeEvent[]>(`https://localhost:5001/api/publicevent`);

    return from(this._authService.getAccessToken().then(token => {
        const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
        return this.httpClient.get<HomeEvent[]>(`https://localhost:5001/api/publicevent`, {headers: headers}).toPromise();
    }));
}
}
