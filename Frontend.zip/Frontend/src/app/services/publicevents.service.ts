import { Injectable } from '@angular/core';
import { HomeEvent} from 'src/model/homeevent';
import { Observable } from 'rxjs';

export interface PubliceventsService {
  getPublicEvents(): Observable<HomeEvent[]>;
}
