export class Constants {
  public static clientRoot = "http://localhost:4200/";

   public static stsAuthority = 'https://dev-im6cdmqs.auth0.com/';

  public static apiRoot = "http://localhost:5001/api/";
   public static clientId = "4D2QP4uaPtxeQaUPhV7O2QFbjVexzUIc";
}
