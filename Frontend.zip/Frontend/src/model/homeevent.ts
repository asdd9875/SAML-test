export class HomeEvent{
    msevtmgt_eventid :string;
    msevtmgt_name: string;
    msevtmgt_eventimage:{
        msdyncrm_blobcdnuri: string;
        msdyncrm_fileid: string;
    };
    msevtmgt_description: string;
    msevtmgt_eventenddate: Date;
    msevtmgt_eventstartdate: Date;
    msevtmgt_eventformat: string;
    msevtmgt_readableeventid: string;
}