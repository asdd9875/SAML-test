﻿using MiddleLayerAPI.Domain.Models;
using MiddleLayerAPI.Domain.Services;
using MiddleLayerAPI.Dynamics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Services
{
    public class EventService : IEventService
    {
       /* private readonly IEventRespository _eventRepository;

        public EventService(IEventRespository eventRepository)
        {
            this._eventRepository = eventRepository;
        }
        */
        public async Task<List<Event>> ListAsync(string readableEventId)
        {
            msevtmgt_event me = new msevtmgt_event();
            return me.GetAll(readableEventId);
            //return await _eventRepository.ListAsync();
        }
    }
}
