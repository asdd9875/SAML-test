﻿using MiddleLayerAPI.Domain.Models;
using MiddleLayerAPI.Domain.Services;
using MiddleLayerAPI.Dynamics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Services
{
    public class PublicEventService: IPublicEventService
    {
        public async Task<List<HomeEvents>> ListAsync()
        {
            DynamicsPublicEvent me = new DynamicsPublicEvent();
            return me.GetAll();
        }
    }
}
