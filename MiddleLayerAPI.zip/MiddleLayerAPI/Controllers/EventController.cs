﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MiddleLayerAPI.Domain.Models;
using MiddleLayerAPI.Domain.Services;

namespace MiddleLayerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        // GET: api/Event
        private readonly IEventService _eventService;

        public EventController(IEventService eventService)
        {
            _eventService = eventService;
        }

        [HttpGet("{id}")]
        public async Task<List<Event>> GetAllAsync(string id)
        {
            Console.WriteLine(id);
            var events = await _eventService.ListAsync(id);
            //Console.WriteLine(id);
            return events;
        }
    }
}
