﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MiddleLayerAPI.Domain.Models;
using MiddleLayerAPI.Domain.Services;

namespace MiddleLayerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PublicEventController : ControllerBase
    {
        private readonly IPublicEventService _publiceventService;

        public PublicEventController(IPublicEventService publiceventService)
        {
            _publiceventService = publiceventService;
        }

        [HttpGet]
        public async Task<List<HomeEvents>> GetAllAsync()
        {
            var events = await _publiceventService.ListAsync();
            //Console.WriteLine(events[0].Id);
            return events;
        }
    }
}
