﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Dynamics.TokenGenerator
{
    public class CrmRequest
    {
        private static string orgUri = "https://devtemdemo.crm8.dynamics.com/api/data/v9.1/";
        public static async Task<HttpResponseMessage> DynamicsCrmRequest(HttpMethod httpMethod, string requestUri, string body = null)
        {
            var accessToken = await TokenGenerator.AccessTokenGenerator();
           // Console.WriteLine(accessToken);
            var client = new HttpClient();
            var message = new HttpRequestMessage(httpMethod, orgUri + requestUri);

            // OData related headers  
            message.Headers.Add("OData-MaxVersion", "4.0");
            message.Headers.Add("OData-Version", "4.0");
            message.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

            // Passing AccessToken in Authentication header  
            message.Headers.Add("Authorization", $"Bearer {accessToken}");

            // Adding body content in HTTP request   
            if (body != null)
                message.Content = new StringContent(body, UnicodeEncoding.UTF8, "application/json");

            return await client.SendAsync(message);
        }
    }
}
