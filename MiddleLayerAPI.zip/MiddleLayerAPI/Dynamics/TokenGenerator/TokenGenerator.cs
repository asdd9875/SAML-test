﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
namespace MiddleLayerAPI.Dynamics.TokenGenerator
{
    public class TokenGenerator
    {

        public static IConfiguration iconfig;

        public static async Task<string> AccessTokenGenerator()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
            string cid = config.GetValue<string>("Dynamics:ClientId");
            //var credentials = new ClientCredential(clientId, clientSecret);
            var credentials = new ClientCredential(config.GetValue<string>("Dynamics:ClientId"), config.GetValue<string>("Dynamics:ClientSecret"));
            var authContext = new Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext(config.GetValue<string>("Dynamics:authority"));
            var result = await authContext.AcquireTokenAsync(config.GetValue<string>("Dynamics:Resource"), credentials);
            //Console.WriteLine(result.AccessToken);
            JwtSecurityToken tt = new JwtSecurityToken(result.AccessToken);
            Console.WriteLine(tt.Payload.Exp);
            //DateTime dd = DateTime.Now;
           //Console.WriteLine(DateTime(tt.Payload.Exp));
            return result.AccessToken;
        }
    }
}
