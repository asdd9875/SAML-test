﻿using MiddleLayerAPI.Domain.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Dynamics
{
    public class msevtmgt_event
    {
        public List<Event> GetAll(string readableEventId)
        {
            var query = "?$select=msevtmgt_description,msevtmgt_eventenddate,msevtmgt_eventformat,msevtmgt_eventid,msevtmgt_eventstartdate,msevtmgt_name,msevtmgt_readableeventid&$expand=msevtmgt_eventimage($select=msdyncrm_blobcdnuri)&$filter=msevtmgt_readableeventid eq '"+ readableEventId + "'&$top=1";
            Console.WriteLine(query);
            var contacts = (TokenGenerator.CrmRequest.DynamicsCrmRequest(
                    HttpMethod.Get,
                    "msevtmgt_events"+query)
                    .Result.Content.ReadAsStringAsync());
            var retrievedcontact1 = JObject.Parse(contacts.Result);
            /*var str1 = JsonConvert.DeserializeObject<object>(contacts.Result.ToString());
            string str2 = str1.ToString().Replace("}\r\n}", "}");
            string str3 = str2.Replace("{\r\n  \"d\":", "");
            Console.WriteLine(str3);*/
            var odata = JsonConvert.DeserializeObject<OData>(contacts.Result);
            return odata.Value;
        }
    }

    public class OData
    {
        // [JsonProperty("odata.metadata")]
        //public string Metadata { get; set; }
        public List<Event> Value { get; set; }
    }
}
