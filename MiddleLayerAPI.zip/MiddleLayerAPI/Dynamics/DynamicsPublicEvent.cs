﻿using MiddleLayerAPI.Domain.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Dynamics
{
    public class DynamicsPublicEvent
    {
        public List<HomeEvents> GetAll()
        {
            var contacts = (TokenGenerator.CrmRequest.DynamicsCrmRequest(
                    HttpMethod.Get,
                    "msevtmgt_events?$select=msevtmgt_eventenddate,msevtmgt_eventid,msevtmgt_eventstartdate,msevtmgt_name,msevtmgt_publishstatus,msevtmgt_readableeventid&$expand=msevtmgt_eventimage($select=msdyncrm_blobcdnuri)&$filter=msevtmgt_publishstatus eq 100000000&$orderby=msevtmgt_eventstartdate asc")
                    .Result.Content.ReadAsStringAsync());
            var retrievedcontact1 = JObject.Parse(contacts.Result);
            
            var odata = JsonConvert.DeserializeObject<OData>(contacts.Result);
            //Console.WriteLine(str3);
            return odata.Value;
        }
        public class OData
        {
            // [JsonProperty("odata.metadata")]
            //public string Metadata { get; set; }
            public List<HomeEvents> Value { get; set; }
        }
    }
}
