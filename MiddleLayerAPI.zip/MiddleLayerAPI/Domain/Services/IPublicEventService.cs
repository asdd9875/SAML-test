﻿using MiddleLayerAPI.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Domain.Services
{
    public interface IPublicEventService
    {
        Task<List<HomeEvents>> ListAsync();
    }
}
