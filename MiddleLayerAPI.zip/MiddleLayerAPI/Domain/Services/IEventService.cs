﻿using MiddleLayerAPI.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Domain.Services
{
    public interface IEventService
    {
        Task<List<Event>> ListAsync(string readableEventId);
    }
}
