﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Domain.Models
{
    public class EventImage
    {
        public string msdyncrm_blobcdnuri { get; set; }
        public string msdyncrm_fileid { get; set; }
    }
}
