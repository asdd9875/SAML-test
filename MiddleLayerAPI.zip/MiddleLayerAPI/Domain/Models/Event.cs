﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MiddleLayerAPI.Domain.Models
{
    public class Event
    {
        public string msevtmgt_eventid { get; set; }
        public string msevtmgt_name { get; set; }
        public EventImage msevtmgt_eventimage { get; set; }
        public string msevtmgt_description { get; set; }
        public DateTime msevtmgt_eventenddate { get; set; }
        public DateTime msevtmgt_eventstartdate { get; set; }
        public string msevtmgt_eventformat { get; set; }
        public string msevtmgt_readableeventid { get; set; }
    }
}