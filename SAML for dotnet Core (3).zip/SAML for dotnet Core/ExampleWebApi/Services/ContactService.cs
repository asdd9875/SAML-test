﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.IO;
using ExampleWebApi.Services;

namespace ExampleWebApi.Services
{
    public class ContactService
    {
        private static string orgUri = "https://temtrialdev.api.crm8.dynamics.com/api/data/v9.1/";
        /*static void Main(string[] args)
        {
            var contacts = CrmRequest(
                HttpMethod.Get,
                "https://asdd9875.api.crm8.dynamics.com/api/data/v9.1/")
                .Result.Content.ReadAsStringAsync();
            // Similarly you can make POST, PATCH & DELETE requests  
        }*/
        public static string t;
        public static int i = 0;
        public static IConfiguration iconfig;
        //private 
        public static async Task<string> AccessTokenGenerator()
        {
            // string clientId = "78213c81-443a-435a-8860-f352d442f897"; // Your Azure AD Application ID  
            // string clientSecret = "cZNO6q.Om_O?NhyMw[jVdRVH01x2A3Pr"; // Client secret generated in your App  
            // string authority = "https://login.microsoftonline.com/656f1e6f-b426-4658-b0c1-71122944a21a"; // Azure AD App Tenant ID  
            // string resourceUrl = "https://temtrialdev.crm8.dynamics.com"; // Your Dynamics 365 Organization URL  
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
            string cid = config.GetValue<string>("Dynamics:ClientId");
            Console.WriteLine(cid);
            //var credentials = new ClientCredential(clientId, clientSecret);
            var credentials = new ClientCredential(config.GetValue<string>("Dynamics:ClientId"), config.GetValue<string>("Dynamics:ClientSecret"));
            var authContext = new Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext(config.GetValue<string>("Dynamics:authority"));
            var result = await authContext.AcquireTokenAsync(config.GetValue<string>("Dynamics:Resource"), credentials);
            return result.AccessToken;
        }

        public static async Task<HttpResponseMessage> CrmRequest(HttpMethod httpMethod, string requestUri, string body = null)
        {
            // Acquiring Access Token 
            //Console.WriteLine(i);
            var accessToken = await AccessTokenGenerator();
//            Console.WriteLine(accessToken);
            //Console.ReadKey();

            var client = new HttpClient();
            var message = new HttpRequestMessage(httpMethod, orgUri + requestUri);

            // OData related headers  
            message.Headers.Add("OData-MaxVersion", "4.0");
            message.Headers.Add("OData-Version", "4.0");
            message.Headers.Add("Prefer", "odata.include-annotations=\"*\"");

            // Passing AccessToken in Authentication header  
            message.Headers.Add("Authorization", $"Bearer {accessToken}");

            // Adding body content in HTTP request   
            if (body != null)
                message.Content = new StringContent(body, UnicodeEncoding.UTF8, "application/json");

            return await client.SendAsync(message);

        }
    }
}
