﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ExampleWebApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ExampleWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        [HttpGet]
        public List<avalue> Get()
        {
            var events = ContactService.CrmRequest(
                HttpMethod.Get,
                "msevtmgt_events")
                .Result.Content.ReadAsStringAsync();
            var retrievedcontact1 = JObject.Parse(events.Result);
            var odata = JsonConvert.DeserializeObject<EventOData>(events.Result);
            var str1 = JsonConvert.DeserializeObject<object>(events.Result.ToString());
            string str2 = str1.ToString().Replace("}\r\n}", "}");
            string str3 = str2.Replace("{\r\n  \"d\":", "");
            var ret = odata.Value;
            Console.WriteLine(ret == null);
            return ret;
        }
    }
    public class avalue
    {
        // [JsonProperty("odata.type")]
        public string msevtmgt_name { get; set; }
        public string msevtmgt_readableeventid { get; set; }
        public string msevtmgt_eventimage { get; set; }
    }
    class EventOData 
    {
        // [JsonProperty("odata.metadata")]
        //public string Metadata { get; set; }
        public List<avalue> Value { get; set; }
    }
}