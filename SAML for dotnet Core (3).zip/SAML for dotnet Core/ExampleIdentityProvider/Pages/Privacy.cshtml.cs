﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ExampleIdentityProvider.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}