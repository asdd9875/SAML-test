﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ExampleIdentityProvider.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
