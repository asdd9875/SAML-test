﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ExampleIdentityProvider.Pages
{
    public class ContactModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
